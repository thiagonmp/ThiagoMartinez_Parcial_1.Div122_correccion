package restaurante;

public abstract class Entrada extends platillo implements Preparacion {
    
    int cant_ingredientes;
    
    public Entrada(String nombre, double precio, TipoPreparacion tipo_preparacion, int cant_ingredientes) {

        super(nombre, precio, tipo_preparacion);
        this.cant_ingredientes = cant_ingredientes;
    }
    
    public int get_ingredientes_cant () {
        return cant_ingredientes;
    }
    
    @Override
    public void preparar() {
        System.out.println("Preparando entrada");
    }


}
