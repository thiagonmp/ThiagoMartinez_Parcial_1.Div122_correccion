package restaurante;

public class PlatoDuplicadoException extends RuntimeException {
    
    private static final String MESSAGE = "ERROR: Plato duplicado";
    
    public PlatoDuplicadoException() {
        this(MESSAGE);
    }
    
    public PlatoDuplicadoException(String message) {
        super(message);
    }
}