package restaurante;

public abstract class PlatoPrincipal extends platillo implements Preparacion{

    double tiempo_coccion;

    public PlatoPrincipal(String nombre, double precio, TipoPreparacion tipo_preparacion, double tiempo_coccion) {
        
        super(nombre, precio, tipo_preparacion);
        this.tiempo_coccion = tiempo_coccion;
    }
    
    public double get_tiempo_coccion () {
        return tiempo_coccion;
    }
    
    @Override
    public void preparar() {
        System.out.println("preparando" + nombre);
    }
}