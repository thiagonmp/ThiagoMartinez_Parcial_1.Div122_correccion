package restaurante;

public abstract class platillo implements Preparacion, Decoracion{

    String nombre;
    double precio;
    TipoPreparacion tipo_preparacion;

    public platillo(String nombre, double precio, TipoPreparacion tipo_preparacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipo_preparacion = tipo_preparacion;
    }

    public String get_nombre() {
        return nombre;
    }

    public double get_precio() {
        return precio;
    }

    public TipoPreparacion get_preparacion() {
        return tipo_preparacion;
    }

    

}
