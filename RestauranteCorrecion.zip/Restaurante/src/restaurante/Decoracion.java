package restaurante;

public interface Decoracion {
    
    public void decorar();
    
}
