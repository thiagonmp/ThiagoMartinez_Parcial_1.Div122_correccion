package restaurante;

public interface Preparacion {
    
    public void preparar();
    
}
