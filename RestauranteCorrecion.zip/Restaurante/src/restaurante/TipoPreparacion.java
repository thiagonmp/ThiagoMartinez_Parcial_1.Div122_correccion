package restaurante;

public enum TipoPreparacion {
    FRIO,
    CALIENTE
}
