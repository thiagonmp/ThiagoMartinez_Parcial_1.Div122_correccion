package restaurante;

public abstract class Postre extends platillo implements Decoracion{
    
    boolean tiene_azucar;
    
    public Postre(String nombre, double precio, TipoPreparacion tipo_preparacion, boolean tiene_azucar) {

        super(nombre, precio, tipo_preparacion);
        this.tiene_azucar = tiene_azucar;
    }
    
    public boolean get_tiene_azucar () {
        return tiene_azucar;
    }
    
    @Override
    public void decorar() {
        System.out.println("Decorando postre");
    }
}