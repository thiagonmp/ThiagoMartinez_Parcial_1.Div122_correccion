package restaurante;

import java.util.ArrayList;

public class Restaurante {

    private ArrayList<platillo> platillos;
    
    public Restaurante(platillo plato) {
        platillos = new ArrayList<>();
        platillos.add(plato);
    }
    
    public void agregarPlato(platillo nuevoPlato) {
        try {
            PlatoExiste(nuevoPlato);
            platillos.add(nuevoPlato);
            System.out.println("Plato agregado: " + nuevoPlato.get_nombre());
        } catch (PlatoDuplicadoException ex){
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void PlatoExiste (platillo plato) {
        for (platillo platoExistente : platillos) {
            if (platoExistente.get_nombre().equals(plato.get_nombre()) &&
                platoExistente.getClass().getSimpleName().equals(plato.getClass().getSimpleName())) {
                throw new PlatoDuplicadoException();
            }
        }
    }
    
    public void mostrarPlatos() {
        if (platillos.isEmpty()) {
            System.out.println("No hay platos registrados.");
            return;
        }

        System.out.println("Platos registrados:");
        for (platillo plato : platillos) {
            System.out.println("Tipo: " + plato.getClass().getSimpleName());
            System.out.println("Nombre: " + plato.get_nombre());
            System.out.println("Precio: $" + plato.get_precio());
            System.out.println("Tipo de preparación: " + plato.get_preparacion());

            if (plato instanceof Entrada entrada) {
                System.out.println("Cantidad de ingredientes: " + entrada.get_ingredientes_cant());
            } else if (plato instanceof PlatoPrincipal platoPrincipal) {
                System.out.println("Tiempo de cocción: " + platoPrincipal.get_tiempo_coccion() + " minutos");
            } else if (plato instanceof Postre postre) {
                System.out.println("Contiene azúcar: " + (postre.get_tiene_azucar() ? "Sí" : "No"));
            }
        }
    }
    
    public void prepararPlato(platillo plato) {
    if (plato instanceof PlatoPrincipal) {
        plato.preparar();
        System.out.println("Plato preparado: " + plato.get_nombre());
    } else {
        System.out.println("El plato no puede ser preparado");
    }
    }
    
    public void decorarPlato(platillo plato) {
        if (plato instanceof Entrada || plato instanceof Postre) {
            plato.preparar();
            System.out.println("Plato decorado: " + plato.get_nombre());
        }
    }

    public void filtrarPorTipoPreparacion(TipoPreparacion tipo) {
        System.out.println("Platos con tipo de preparación: " + tipo);
        boolean encontrado = false;

        for (platillo plato : platillos) {
            if (plato.get_preparacion().equals(tipo)) {
                System.out.println("  - " + plato.get_nombre() + " (Precio: $" + plato.get_precio() + ")");
                encontrado = true;
            }
        }

        if (encontrado == false) {
            System.out.println("  - No se encontraron platos con ese tipo de preparación.");
        }
    }
    
    public void mostrarPlatosPorTipo(String tipoPlato) {
        boolean encontrado = false;

        System.out.println("Platos del tipo: " + tipoPlato);
        for (platillo plato : platillos) {
            if (plato.getClass().getSimpleName().equals(tipoPlato)) {
                System.out.println("  - " + plato.get_nombre() + " (Precio: $" + plato.get_precio() + ")");
                System.out.println("");
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("  - No se encontraron platos de tipo " + tipoPlato + ".");
    }
}

}